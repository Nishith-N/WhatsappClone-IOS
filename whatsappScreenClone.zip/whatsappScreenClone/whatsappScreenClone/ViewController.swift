import UIKit
class tablelist {
    var profIcon: String?
    var contactName: String?
    var messageLbl: String?
    var timeLbl: String?
    var noticon: String?

    init(initprof:String, initcont:String, initmsg:String, inittime:String, initnicon:String) {
        self.profIcon = initprof
        self.contactName = initcont
        self.messageLbl = initmsg
        self.timeLbl = inittime
        self.noticon = initnicon
    }
}
class ViewController: UIViewController {
    var itemArray = [tablelist]()
    let width = UIScreen.main.bounds.size.width
    let height = UIScreen.main.bounds.size.height
   
    var tableView = UITableView()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.cyan
        let tableviewcell1 = tablelist(initprof: "images-1", initcont: "James", initmsg: "Here we go!!!", inittime: "21:37", initnicon: "1")
        itemArray.append(tableviewcell1)
        let tableviewcell2 = tablelist(initprof: "images-2", initcont: "Reece", initmsg: "Tday's plan....?", inittime: "17:08", initnicon: "0")
        itemArray.append(tableviewcell2)
        let tableviewcell3 = tablelist(initprof: "images-3", initcont: "Trent", initmsg: "cme faast", inittime: "01:01", initnicon: "0")
        itemArray.append(tableviewcell3)
        let tableviewcell4 = tablelist(initprof: "images-4", initcont: "Arnold", initmsg: "gud night", inittime: "23:58", initnicon: "4")
        itemArray.append(tableviewcell4)
        let tableviewcell5 = tablelist(initprof: "images-5", initcont: "Xavi", initmsg: "u r welcome", inittime: "06:32", initnicon: "0")
        itemArray.append(tableviewcell5)
        let tableviewcell6 = tablelist(initprof: "images-6", initcont: "Pele", initmsg: "ok bro", inittime: "02:32", initnicon: "0")
        itemArray.append(tableviewcell6)
        let tableviewcell7 = tablelist(initprof: "images-7", initcont: "Kessie", initmsg: "Tday?", inittime: "05:52", initnicon: "6")
        itemArray.append(tableviewcell7)
        tableView.isScrollEnabled = true
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(CustomTableViewCell.self, forCellReuseIdentifier: "Cell")
        let screenSize = UIScreen.main.bounds.size
        tableView.frame=CGRect(x: 0, y: 0, width: screenSize.width, height: screenSize.height)
        view.addSubview(tableView)
        // Do any additional setup after loading the view.
    }

}

extension ViewController:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)as?
                CustomTableViewCell else {fatalError("Unable to run")}
      cell.profimage.image = UIImage(named: itemArray[indexPath.row].profIcon!)
        cell.contacts.text = itemArray[indexPath.row].contactName
        cell.msge.text = itemArray[indexPath.row].messageLbl
       cell.timelbl.text = itemArray[indexPath.row].timeLbl
        cell.notifilbl.text = itemArray[indexPath.row].noticon
        if(cell.notifilbl.text == "0")
        {
            
            cell.notifilbl.isHidden = true
        }
        else
        {
            cell.notifilbl.isHidden = false
        }
        cell.notifilbl.layer.cornerRadius = 15
        cell.notifilbl.clipsToBounds = true

        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    
    
    
    
    
}

